export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCjCX6eb2iXMG8yBASGrIaWAw9e3nkD7Ks",
    authDomain: "tourdeparole.firebaseapp.com",
    databaseURL: "https://tourdeparole.firebaseio.com",
    projectId: "tourdeparole",
    storageBucket: "tourdeparole.appspot.com",
    messagingSenderId: "913643563971"
  }
};
